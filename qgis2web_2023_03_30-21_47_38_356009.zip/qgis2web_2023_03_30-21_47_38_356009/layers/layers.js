var wms_layers = [];

var format_ADMINISTRASIKECAMATAN_AR_50K_0 = new ol.format.GeoJSON();
var features_ADMINISTRASIKECAMATAN_AR_50K_0 = format_ADMINISTRASIKECAMATAN_AR_50K_0.readFeatures(json_ADMINISTRASIKECAMATAN_AR_50K_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ADMINISTRASIKECAMATAN_AR_50K_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ADMINISTRASIKECAMATAN_AR_50K_0.addFeatures(features_ADMINISTRASIKECAMATAN_AR_50K_0);
var lyr_ADMINISTRASIKECAMATAN_AR_50K_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_ADMINISTRASIKECAMATAN_AR_50K_0, 
                style: style_ADMINISTRASIKECAMATAN_AR_50K_0,
                interactive: true,
    title: 'ADMINISTRASIKECAMATAN_AR_50K<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_0.png" /> ADILUWIH<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_1.png" /> AMBARAWA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_2.png" /> BANGUNREJO<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_3.png" /> BEKRI<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_4.png" /> BUMIRATU NUBAN<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_5.png" /> CUKUHBALAK<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_6.png" /> GADINGREJO<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_7.png" /> GEDONGTATAAN<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_8.png" /> KALIREJO<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_9.png" /> KEDONDONG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_10.png" /> KELUMBAYAN<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_11.png" /> KELUMBAYAN BARAT<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_12.png" /> MARGAPUNDUH<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_13.png" /> NATAR<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_14.png" /> NEGERIKATON<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_15.png" /> PADANGCERMIN<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_16.png" /> PARDASUKA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_17.png" /> PUNDUHPEDADA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_18.png" /> SUKOHARJO<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_19.png" /> TEGINENENG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_20.png" /> WAYKHILAU<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_21.png" /> WAYLIMA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_22.png" /> <br />'
        });
var format_ARENAOLAHRAGA_PT_50K_1 = new ol.format.GeoJSON();
var features_ARENAOLAHRAGA_PT_50K_1 = format_ARENAOLAHRAGA_PT_50K_1.readFeatures(json_ARENAOLAHRAGA_PT_50K_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ARENAOLAHRAGA_PT_50K_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ARENAOLAHRAGA_PT_50K_1.addFeatures(features_ARENAOLAHRAGA_PT_50K_1);
var lyr_ARENAOLAHRAGA_PT_50K_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_ARENAOLAHRAGA_PT_50K_1, 
                style: style_ARENAOLAHRAGA_PT_50K_1,
                interactive: true,
    title: 'ARENAOLAHRAGA_PT_50K<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_0.png" /> Lapangan Bangunrejo<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_1.png" /> Lapangan Bola Harapanjaya<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_2.png" /> Lapangan Bola Pesawaran<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_3.png" /> Lapangan Bola Sinarharapan<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_4.png" /> Lapangan Bunutseberang<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_5.png" /> Lapangan Enggalrejo<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_6.png" /> Lapangan Gayau<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_7.png" /> Lapangan Gunungrejo<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_8.png" /> Lapangan Kebagusan<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_9.png" /> Lapangan Kedondong<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_10.png" /> Lapangan Margomulyo<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_11.png" /> Lapangan Pesawaranindah<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_12.png" /> Lapangan Poncokresno<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_13.png" /> Lapangan Poncorejo<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_14.png" /> Lapangan Rejoagung<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_15.png" /> Lapangan Sepakbola Waydadi<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_16.png" /> Lapangan Sinarbandung<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_17.png" /> Lapangan Srikaton<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_18.png" /> Lapangan Sumberjaya<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_19.png" /> Lapangan Tanjungpandan<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_20.png" /> Lapangan Tempelrejo<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_21.png" /> Lapangan Trimulyo<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_22.png" /> Lapangan Tunggulpawenang<br />\
    <img src="styles/legend/ARENAOLAHRAGA_PT_50K_1_23.png" /> <br />'
        });

lyr_ADMINISTRASIKECAMATAN_AR_50K_0.setVisible(true);lyr_ARENAOLAHRAGA_PT_50K_1.setVisible(true);
var layersList = [lyr_ADMINISTRASIKECAMATAN_AR_50K_0,lyr_ARENAOLAHRAGA_PT_50K_1];
lyr_ADMINISTRASIKECAMATAN_AR_50K_0.set('fieldAliases', {'KDPPUM': 'KDPPUM', 'NAMOBJ': 'NAMOBJ', 'REMARK': 'REMARK', 'KDPBPS': 'KDPBPS', 'FCODE': 'FCODE', 'LUASWH': 'LUASWH', 'UUPP': 'UUPP', 'SRS_ID': 'SRS_ID', 'LCODE': 'LCODE', 'METADATA': 'METADATA', 'KDEBPS': 'KDEBPS', 'KDEPUM': 'KDEPUM', 'KDCBPS': 'KDCBPS', 'KDCPUM': 'KDCPUM', 'KDBBPS': 'KDBBPS', 'KDBPUM': 'KDBPUM', 'WADMKD': 'WADMKD', 'WIADKD': 'WIADKD', 'WADMKC': 'WADMKC', 'WIADKC': 'WIADKC', 'WADMKK': 'WADMKK', 'WIADKK': 'WIADKK', 'WADMPR': 'WADMPR', 'WIADPR': 'WIADPR', 'TIPADM': 'TIPADM', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ARENAOLAHRAGA_PT_50K_1.set('fieldAliases', {'NAMOBJ': 'NAMOBJ', 'FCODE': 'FCODE', 'ELEVAS': 'ELEVAS', 'REMARK': 'REMARK', 'SRS_ID': 'SRS_ID', 'LCODE': 'LCODE', 'METADATA': 'METADATA', });
lyr_ADMINISTRASIKECAMATAN_AR_50K_0.set('fieldImages', {'KDPPUM': 'TextEdit', 'NAMOBJ': 'TextEdit', 'REMARK': 'TextEdit', 'KDPBPS': 'TextEdit', 'FCODE': 'TextEdit', 'LUASWH': 'TextEdit', 'UUPP': 'TextEdit', 'SRS_ID': 'TextEdit', 'LCODE': 'TextEdit', 'METADATA': 'TextEdit', 'KDEBPS': 'TextEdit', 'KDEPUM': 'TextEdit', 'KDCBPS': 'TextEdit', 'KDCPUM': 'TextEdit', 'KDBBPS': 'TextEdit', 'KDBPUM': 'TextEdit', 'WADMKD': 'TextEdit', 'WIADKD': 'TextEdit', 'WADMKC': 'TextEdit', 'WIADKC': 'TextEdit', 'WADMKK': 'TextEdit', 'WIADKK': 'TextEdit', 'WADMPR': 'TextEdit', 'WIADPR': 'TextEdit', 'TIPADM': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', });
lyr_ARENAOLAHRAGA_PT_50K_1.set('fieldImages', {'NAMOBJ': 'TextEdit', 'FCODE': 'TextEdit', 'ELEVAS': 'TextEdit', 'REMARK': 'TextEdit', 'SRS_ID': 'TextEdit', 'LCODE': 'TextEdit', 'METADATA': 'TextEdit', });
lyr_ADMINISTRASIKECAMATAN_AR_50K_0.set('fieldLabels', {'KDPPUM': 'no label', 'NAMOBJ': 'no label', 'REMARK': 'no label', 'KDPBPS': 'no label', 'FCODE': 'no label', 'LUASWH': 'no label', 'UUPP': 'no label', 'SRS_ID': 'no label', 'LCODE': 'no label', 'METADATA': 'no label', 'KDEBPS': 'no label', 'KDEPUM': 'no label', 'KDCBPS': 'no label', 'KDCPUM': 'no label', 'KDBBPS': 'no label', 'KDBPUM': 'no label', 'WADMKD': 'no label', 'WIADKD': 'no label', 'WADMKC': 'no label', 'WIADKC': 'no label', 'WADMKK': 'no label', 'WIADKK': 'no label', 'WADMPR': 'no label', 'WIADPR': 'no label', 'TIPADM': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ARENAOLAHRAGA_PT_50K_1.set('fieldLabels', {'NAMOBJ': 'no label', 'FCODE': 'no label', 'ELEVAS': 'no label', 'REMARK': 'no label', 'SRS_ID': 'no label', 'LCODE': 'no label', 'METADATA': 'no label', });
lyr_ARENAOLAHRAGA_PT_50K_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});